export interface User {
  userId: number;
  name: string;
  email: string;
  role: string;
  active: boolean;
  registrationDate: string;
}
