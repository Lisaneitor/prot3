import { Component } from '@angular/core';

@Component({
  selector: 'app-oferta-form',
  standalone: false,
  templateUrl: './oferta-form.component.html',
  styleUrl: './oferta-form.component.css'
})
export class OfertaFormComponent {

}
