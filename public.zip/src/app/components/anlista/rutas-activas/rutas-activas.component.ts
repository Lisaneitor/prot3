import { Component } from '@angular/core';

@Component({
  selector: 'app-rutas-activas',
  standalone: false,
  templateUrl: './rutas-activas.component.html',
  styleUrl: './rutas-activas.component.css'
})
export class RutasActivasComponent {

}
